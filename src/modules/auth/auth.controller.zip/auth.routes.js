const express = require('express');
const { register, bootstrapSuperAdmin, login, logout, changePassword } = require('./auth.controller');
const { validate } = require('../../core/middlewares/validate.middleware');
const { loginSchema, registerSchema, bootstrapSuperAdminSchema, changePasswordSchema } = require('../../validators/auth.schema');
const { authMiddleware, authorize } = require('../../core/middlewares');
const { ROLES } = require('../../core/constants/roles');

const router = express.Router();

router.post('/bootstrap-superadmin', validate(bootstrapSuperAdminSchema), bootstrapSuperAdmin);
router.post('/register', authMiddleware, authorize(ROLES.SUPER_ADMIN, ROLES.ADMIN), validate(registerSchema), register);
router.post('/login', validate(loginSchema), login);
router.post('/logout', logout);  // No requiere auth, es idempotente
router.post('/change-password', authMiddleware, validate(changePasswordSchema), changePassword);

module.exports = router;
